import React, { useState } from "react";
import "../styles/LoginModal.css";
import { GoogleLogin } from "@react-oauth/google";
import { jwtDecode } from "jwt-decode";

export default function LoginModal({ open, onClose }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!open) return null;

  const handleLogin = (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate login process
    setTimeout(() => {
      console.log("Login attempted with:", { email, password });
      setIsLoading(false);
      // Add your login logic here
    }, 1000);
  };



  const handleOverlayClick = (e) => {
    if (e.target.className === "login-overlay") {
      onClose();
    }
  };

  return (
    <div className="login-overlay" onClick={handleOverlayClick}>
      <div className="login-modal">

            <h2 className="divider">Welcome Back</h2>

        <form onSubmit={handleLogin} className="login-form">
          <label>Email address<small>*</small></label>
          <input
            type="email"
            className="input"
    
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <label>Password<small>*</small></label>
          <input
            type="password"
            className="input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button 
            type="submit" 
            className="new-chat-btn"
            disabled={isLoading}
          >
            {isLoading ? "Logging in..." : "Login"}
          </button>
        </form>

        <div className="divider">OR</div>

         <GoogleLogin
            onSuccess={(res) => {
                const user = jwtDecode(res.credential);
                console.log(user);
            }}
            onError={() => {
                console.log("Login Failed");
            }}
            />

        
      </div>
    </div>
  );
}